package com.capgemini.salesmanagement.exceptions;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException() {
		System.out.println("product is not found");
	}
}