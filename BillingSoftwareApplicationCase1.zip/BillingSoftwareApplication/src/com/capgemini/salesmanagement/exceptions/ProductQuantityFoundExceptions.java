package com.capgemini.salesmanagement.exceptions;

public class ProductQuantityFoundExceptions extends Exception {
	public ProductQuantityFoundExceptions()
	{
		System.out.println("Quantity is not valid");	
	}
}
