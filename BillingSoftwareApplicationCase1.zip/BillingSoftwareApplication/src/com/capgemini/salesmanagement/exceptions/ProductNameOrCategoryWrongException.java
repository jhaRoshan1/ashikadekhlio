package com.capgemini.salesmanagement.exceptions;

public class ProductNameOrCategoryWrongException extends Exception {
public ProductNameOrCategoryWrongException()
{
	System.out.println("Product name or category is wrong");
}
}
