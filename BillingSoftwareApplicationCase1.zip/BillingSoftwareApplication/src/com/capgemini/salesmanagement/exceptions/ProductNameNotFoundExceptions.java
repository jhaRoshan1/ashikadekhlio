package com.capgemini.salesmanagement.exceptions;

public class ProductNameNotFoundExceptions extends Exception {
	public ProductNameNotFoundExceptions()
	{
		System.out.println("Product name is not valid");
	}
}
