package com.capgemini.salesmanagement.exceptions;

public class ProductPriceNotFoundExceptions extends Exception {
	public ProductPriceNotFoundExceptions(){
		System.out.println("Product price is not valid");
	}
}
