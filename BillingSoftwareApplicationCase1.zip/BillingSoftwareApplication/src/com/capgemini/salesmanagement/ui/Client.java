package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.ProductNameNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductNameOrCategoryWrongException;
import com.capgemini.salesmanagement.exceptions.ProductNotFoundException;
import com.capgemini.salesmanagement.exceptions.ProductPriceNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductQuantityFoundExceptions;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	public static void main(String args[]) {
		ISaleService services=new SaleService();
	
		Scanner sc=new Scanner(System.in);

		while(true)
		{
			System.out.println("1:Display the bill \n.2: exit");
			System.out.println("enter your choice ");
			int ch=sc.nextInt();

			switch (ch) {
			case 1:System.out.println("enter the Details :");
			
				try {
					System.out.println("enter product code");
					int prodCode=sc.nextInt();
							services.validateProductCode(prodCode);
					
					System.out.println("enter productName ");
					String productName=sc.next();
					services.validateProductName(productName);
					
					System.out.println("enter category");
					String category=sc.next();
					
					services.validateProductCat(category) ;
				      try {
						services.validateProductNameAndCategory(productName, category);
					} catch (ProductNameOrCategoryWrongException e) {
					}
					
					System.out.println("enter quantity");
					int quantity=sc.nextInt();
					services.validateQuantity(quantity);
					
					System.out.println("enter price");
					float price=sc.nextFloat();
                    services.validateProductPrice(price);
                    float lineTotal=price*quantity;
                   
                    Sale sale=new Sale(prodCode, productName, category, quantity, price, lineTotal);
                    HashMap<Integer, Sale>sale1=services.insertSalesDetails(sale);
                    Set entrySet=sale1.entrySet();
                    Iterator itr=entrySet.iterator();
                    while(itr.hasNext()) {
                    	Map.Entry me= (Map.Entry)itr.next();
                    	System.out.println(me.getValue());
                    }
				
				} catch (ProductNotFoundException e) {
				
				} catch (ProductNameNotFoundExceptions e) {
					
				} catch (ProductQuantityFoundExceptions e) {
					
				} catch (ProductPriceNotFoundExceptions e) {		
				}
			
			break;
			case 2:System.exit(0);
			default:System.out.println("wrong choice");
				
			}


		}

	}
}