 package com.capgemini.salesmanagement.util;
import java.util.HashMap;
import com.capgemini.salesmanagement.bean.Sale;

public class CollectionUtil {
	public static HashMap<Integer, Sale> sales=new HashMap<Integer, Sale>();
	
	
	public static int getSALE_ID_COUNTER() {
		return  (int)(Math.random()*1000);
	}
	public static HashMap<Integer, Sale>getCollection(){
		return sales;
	}
}
