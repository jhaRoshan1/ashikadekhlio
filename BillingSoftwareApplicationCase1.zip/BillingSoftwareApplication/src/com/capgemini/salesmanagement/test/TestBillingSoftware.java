package com.capgemini.salesmanagement.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.ProductQuantityFoundExceptions;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;


public class TestBillingSoftware {
	private static ISaleService services;
	@BeforeClass
	public static void setUpTestEnv()  {
		services=new SaleService();
	}
	@Before
	public void setUpTestData() {
		Sale sale1=new Sale(1001, "TV", "Electronics", 5, 500);
		Sale sale2=new Sale(1002, "TV", "Electronics", 4, 800);
		CollectionUtil.sales.put(sale1.getSaleId(), sale1);
		CollectionUtil.sales.put(sale2.getSaleId(), sale2);
	}
	@Test
	public void testInsertSaleForValidQuantity() throws ProductQuantityFoundExceptions {
		boolean  expectedValue=true;	
		boolean actualValue = services.validateQuantity(5);
		Assert.assertEquals(expectedValue, actualValue);
	}
	@Test(expected=ProductQuantityFoundExceptions.class)
	public void testInsertForInvalidQuantity() throws ProductQuantityFoundExceptions {
		boolean actualValue = services.validateQuantity(6);
	}
	@After
	public void tearDownTestData() {
		CollectionUtil.sales.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}

}
