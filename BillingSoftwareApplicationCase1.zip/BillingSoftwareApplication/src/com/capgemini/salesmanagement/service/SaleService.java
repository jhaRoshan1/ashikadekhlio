package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.ProductNameNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductNameOrCategoryWrongException;
import com.capgemini.salesmanagement.exceptions.ProductNotFoundException;
import com.capgemini.salesmanagement.exceptions.ProductPriceNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductQuantityFoundExceptions;

public class SaleService implements ISaleService {
//implementing all the methods of ISaleService interface hereI
ISaleDAO isaleDao=new SaleDAO();
	
	
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		return (isaleDao.insertSalesDetails(sale));
	
	}
	@Override
	public boolean validateProductPrice(float Price)throws ProductPriceNotFoundExceptions {
 if(Price>200)
	return true;
else
		throw new ProductPriceNotFoundExceptions();
	}
	@Override
	public boolean validateProductCode(int prodCode) throws ProductNotFoundException {
		if(prodCode==1001||prodCode==1002||prodCode==1003||prodCode==1004)
			return true;
		else
		throw new ProductNotFoundException();
	}

	@Override
	public boolean validateQuantity(int quantity) throws ProductQuantityFoundExceptions {
		if(quantity>0&&quantity<=5)
			return true;
			throw new ProductQuantityFoundExceptions();
		
	}
	@Override
	public boolean validateProductCat(String prodCat) throws ProductNameNotFoundExceptions {
		if(prodCat.equalsIgnoreCase("electronics")||prodCat.equalsIgnoreCase("toys"))
			return true;
		else
		throw new ProductNameNotFoundExceptions();
	}
	@Override
	public boolean validateProductName(String prodName) throws ProductNameNotFoundExceptions {
		if(prodName.equalsIgnoreCase("tv")||prodName.equalsIgnoreCase("smart phone")||prodName.equalsIgnoreCase("video game")||
				prodName.equalsIgnoreCase("soft toy")||prodName.equalsIgnoreCase("telescope")||prodName.equalsIgnoreCase("barbee doll"))
			return true;
		else
		throw new ProductNameNotFoundExceptions();
	}
	@Override
	public boolean validateProductNameAndCategory(String prodName, String prodCat)
			throws ProductNameOrCategoryWrongException {
		if((prodCat.equalsIgnoreCase("electronics")&&prodName.equalsIgnoreCase("tv")||prodName.equalsIgnoreCase("smart phone")||
				prodName.equalsIgnoreCase("video game"))||(prodCat.equalsIgnoreCase("toys")&&prodName.equalsIgnoreCase("soft toy")||prodName.equalsIgnoreCase("telescope")||prodName.equalsIgnoreCase("barbee doll")))
		{
			return true;
	    }
		else
			throw new ProductNameOrCategoryWrongException();
	}
}
