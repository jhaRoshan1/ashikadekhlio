//service utility classes and interfaces
package com.capgemini.salesmanagement.service;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.ProductNameNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductNameOrCategoryWrongException;
import com.capgemini.salesmanagement.exceptions.ProductNotFoundException;
import com.capgemini.salesmanagement.exceptions.ProductPriceNotFoundExceptions;
import com.capgemini.salesmanagement.exceptions.ProductQuantityFoundExceptions;

public interface ISaleService {
public HashMap<Integer, Sale>insertSalesDetails(Sale sale);
public boolean validateProductCode(int prodCode)throws ProductNotFoundException;
public boolean validateQuantity(int quantity)throws ProductQuantityFoundExceptions;
public boolean validateProductCat(String prodCat)throws ProductNameNotFoundExceptions;
public boolean validateProductPrice(float Price)throws ProductPriceNotFoundExceptions;
public boolean validateProductName(String prodName)throws ProductNameNotFoundExceptions;
public boolean validateProductNameAndCategory(String prodName,String prodCat)throws ProductNameOrCategoryWrongException;
}
